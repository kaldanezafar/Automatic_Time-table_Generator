<?php

require('config.php');

$msg = "";
// print_r($_SESSION);

if(isset($_POST['section']))
{
    $class = $_POST['class'];
    $section = $_POST['section'];

    if(empty($class))
    {
        $msg = "Please Select Class";
    }
    elseif(empty($section))
    {
        $msg = "Please Select Section";
    }
    else
    {
      $sql = "SELECT sm.*,s.subject_name FROM `tbl_timetable` sm JOIN `tbl_subject` s ON sm.subject=s.id WHERE `section`='".$section."' AND `class`='".$class."'";
      $stmt = $conn->query($sql);
      $row_count = $stmt->rowCount();

      if(!$row_count)
      {
        $sql = "SELECT * FROM `tbl_subject_mapping` WHERE `section`='".$section."' AND `class`='".$class."'";
        $stmt = $conn->query($sql);
        $row = $stmt->rowCount();
        if($row>0)
        {
          if($row<5)
          {
            $msg = 'There Must Be 5 Subject To Create Timetable';
          }
          else if($row>5)
          {
            $msg = 'Please Add Only 5 Subject To Create Timetable';
          }
          else
          {
            $period = range(1, 5);
            $subject_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
            // print_r($period);
            for ($i=1; $i <= 6; $i++)
            {
                shuffle($period);
                // print_r($period);
                foreach ($subject_list as $key => $value)
                {
                  // echo $period[$key].'<br>';
                    $sql = "INSERT INTO `tbl_timetable`(`id`, `class`, `section`, `subject`, `day`, `period`, `added_date`, `updated_date`, `isDeleted`) VALUES (NULL,'".$value['class']."','".$value['section']."','".$value['subject']."','".$i."','".$period[$key]."','".date('Y-m-d H:i:s')."','".date('Y-m-d H:i:s')."',0)";
                    $stmt = $conn->query($sql);
                }
            }
            // print_r($subject_list);
            $msg = '<span style="color:red;">Timetable Created Successfully</span>';
          }
        }
        else
        {
            $msg = 'No Subject For This Section And Class';
        }
      }
      else
      {
        $msg = 'Already Created';
      }
    }
}

$sql = "SELECT * FROM `tbl_subject` WHERE `isDeleted`=0";
$stmt = $conn->query($sql);
$subject_list = $stmt->fetchAll(PDO::FETCH_ASSOC);

// print_r($subject_list);
?>
<!doctype html>
<html>
<head>
  <title>Create Timetable</title>
  <link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>
  <?php require('header.php'); ?>
       <div class="centerdiv">
        <h4 style="color: black;text-align: center;"><?php echo $msg; ?></h4>
        <form action="#" method="POST">
          <fieldset>
            <legend><b> Create Timetable:</b></legend>
            <label>SECTION:</label><br>
              <select name="section" required>
                <option <?= (isset($_POST['section']) && $_POST['section']=='BCOM')?'selected':''; ?> value="BCOM">BCOM</option>
                <option <?= (isset($_POST['section']) && $_POST['section']=='BSC(I.T)')?'selected':''; ?> value="BSC(I.T)">BSC(I.T)</option>
                <option <?= (isset($_POST['section']) && $_POST['section']=='BMS')?'selected':''; ?> value="BMS">BMS</option>
                <option <?= (isset($_POST['section']) && $_POST['section']=='BAF')?'selected':''; ?> value="BAF">BAF</option>
                <option <?= (isset($_POST['section']) && $_POST['section']=='BMM')?'selected':''; ?> value="BMM">BMM</option>
              </select>

          <br>    <br>
           <label>CLASS:</label> <br>

           <select name="class" required>
            <option <?= (isset($_POST['class']) && $_POST['class']=='F.Y')?'selected':''; ?> value="F.Y">F.Y</option>
            <option <?= (isset($_POST['class']) && $_POST['class']=='S.Y')?'selected':''; ?> value="S.Y">S.Y</option>
            <option <?= (isset($_POST['class']) && $_POST['class']=='T.Y')?'selected':''; ?> value="T.Y">T.Y</option>

          </select>

          <br> <br>

          <button style="padding: 10px;border-radius: 20px;">SAVE</button> 
          <!-- <button style="padding: 10px;border-radius: 20px;margin-left: 50px;">DELETE</button>  -->
        <button  type="button" style="padding:10px; border-radius: 20px; margin-left: 50px;" onclick="location.href='index.php'">EXIT</button>
        </fieldset>
      </form>
    </div>

  </body>
  </html>