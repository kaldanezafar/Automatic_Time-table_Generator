<?php

require('config.php');

$msg = "";
// print_r($_SESSION);

if(isset($_POST['admin_id']))
{
    $admin_id = $_POST['admin_id'];
    $password = $_POST['password'];

    if(empty($admin_id))
    {
        $msg = "Please Enter Admin ID";
    }
    elseif(empty($password))
    {
        $msg = "Please Enter Password";
    }
    else
    {
        $sql = "SELECT * FROM `tbl_admin` WHERE `email`='".$admin_id."' AND `password`='".$password."' AND `isDeleted`=0";
        $stmt = $conn->query($sql);
        if($stmt->rowCount()>0)
        {
            $msg = 'Login Successfully';
            $_SESSION['admin_id'] = $admin_id;
            $_SESSION['password'] = $password;
        }
        else
        {
            $msg = 'Please Enter Valid Credential';
        }
    }
}

if(isset($_SESSION['admin_id']))
{
  header('location: index.php');
}

?>
<!doctype html>
<html>
<head>
    <title>loginpage</title>
    <link rel="stylesheet" type="text/css" href="css/login.css.css">
    <body>
        <div class="bgimg">
            <div class="centerdiv">
            <img src="images/icon.png" id="logo">
                <h2>Time Table Generater</h2>
                <h5 style="text-align: center; font-size: 30px;">ADMIN LOGIN</h5>
                <h4 style="color: black;text-align: center;"><?php echo $msg; ?></h4>
                <form method="post">
                    <div>
                        <input type="text" name="admin_id" class="inputbox" placeholder="admin id" >
                    </div>
                    <br>
                    <div>
                        <input type="password" name="password" class="inputbox" placeholder="password" >
                    </div>
                    <br>
                    <div>
                        <!-- <input type="checkbox" name="password" style="margin-left:30px;">Remember me -->

                        <!-- <a href="change-password.php"> CHANGE PASSWORD</a> -->
                    </div>
                    <br>
                    <div>
                       <button>LOGIN</button>
                   </div>
               </form>
            
            </div>
    </div>    
    </body>
    </head>
</html>