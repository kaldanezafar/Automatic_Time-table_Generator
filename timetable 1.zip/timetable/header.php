
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js">
  
</script>

<script type="text/javascript">
  $(document).ready( function () {
    $('#myTable').DataTable({
    pageLength : 4,
    lengthMenu: [[4, 8], [4, 8]]
  });
} );
</script>
<div id="menu">
    <ul>
      <li><a href="#">Create</a>
        <ul>
         <li><a href="create-student.php">create student</a></li>
         <li><a href="create-staff.php">create staff</a></li>
        <li><a href="create-subject.php">create subject</a></li>
       </ul>
     </li>
     <li><a href="#">List</a>
        <ul>
         <li><a href="student-list.php">student list</a></li>
         <li><a href="staff-list.php">staff list</a></li>
        <li><a href="subject-list.php">subject list</a></li>
<li><a href="mapping-list.php">mapping list</a></li>
       </ul>
     </li>
     <li><a href="#">timetable</a>
      <ul>
        <li><a href="add-subject-to-class.php">add subject to class</a></li>
        <li><a href="create-timetable.php">create timetable</a></li>
        <li><a href="timetable-list.php">saved timetable</a></li>
       </ul>
       </li> 
           <!-- <li><a href="send-notification.php">send notification</a></li> -->
           <li><a href="index.php?logout" onclick="return confirm('Are You Sure Want To Logout')">logout</a></li>
         </ul>

       </div>