<?php

require('config.php');

$msg = "";
// print_r($_SESSION);
if(isset($_POST['subject_id']))
{
    $subject_id  = $_POST['subject_id'];
    $subject_name = $_POST['subject_name'];
    $display_color = $_POST['display_color'];
   


    if(empty($subject_id))
    {
        $msg = "Please Enter subject_id ID";
    }
    elseif(empty($subject_name))
    {
        $msg = "Please Enter subject name";
    }
    else
    {
        $sql = "INSERT INTO `tbl_subject`(`id`,`subject_id`, `subject_name`, `display_color`, `password`, `status`, `added_date`, `updated_date`, `isDeleted`)  VALUES (NULL,'".$subject_id."','".$subject_name."','".$display_color."','1234',0,NOW(),NOW(),0)";
        $stmt = $conn->query($sql);
        if($stmt->rowCount()>0)
        {
          $msg = '<span style="color:green;">Subject Created Successfully</span>';
           
        }
        else
        {
            $msg = 'Please Enter Valid Credential';
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <title>create student</title>
  <link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>
   <?php require('header.php'); ?>
        <div class="centerdiv"> 
          <h4 style="color: black;text-align: center;"><?php echo $msg; ?></h4>
         <form action="" method="post">
          <fieldset>
           <legend><b> CREATE SUBJECT:</b></legend>


           <label>SUBJECT ID:</label> <br>
           <input type="text" name="subject_id" placeholder="ENTER SUBJECT ID" required="">
           <br>    <br>


           <label>SUBJECT NAME:</label><br>
           <input type="text" name="subject_name" placeholder="ENTER SUBJECT NAME" required="">

           <br>   <br>

           <label>DISPLAY COLOUR:</label><br>
           <input type="color" name="display_color">

           <br>    <br>
           <button style="padding: 10px;border-radius: 20px;">SAVE</button> 
           <!-- <button style="padding: 10px;border-radius: 20px;margin-left: 50px;">DELETE</button>  -->
           <button style="padding:10px; border-radius: 20px; margin-left: 50px;" onclick="location.href='index.php'">EXIT</button>

         </fieldset>
       </form>
     </div>

   </body>
   </html>