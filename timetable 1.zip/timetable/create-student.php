<?php

require('config.php');

$msg = "";
// print_r($_SESSION);

if(isset($_POST['student_id']))
{
    $student_id = $_POST['student_id'];
    $student_name = $_POST['student_name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $class = $_POST['class'];
    $section = $_POST['section'];


    if(empty($student_id))
    {
        $msg = "Please Enter Student ID";
    }
    elseif(empty($student_name))
    {
        $msg = "Please Enter Password";
    }
    else
    {
        $sql = "INSERT INTO `tbl_student`(`id`,`student_id`, `student_name`, `email`, `contactno`,`class`,`section`, `password`, `status`, `added_date`, `updated_date`, `isDeleted`)  VALUES (NULL,'".$student_id."','".$student_name."','".$email."','".$mobile."','".$class."','".$section."','1234',0,NOW(),NOW(),0)";
        $stmt = $conn->query($sql);
        if($stmt->rowCount()>0)
        {
          $msg = '<span style="color:green;">student Created Successfully</span>';
           
        }
        else
        {
            $msg = 'Please Enter Valid Credential';
        }
    }
}
?>
<!doctype html>
<html>
<head>
    <title>create student</title>
    <link rel="stylesheet" type="text/css" href="css/index.css">
    </head>
    <body>
      <?php require('header.php'); ?>
        <div class="centerdiv">
          <h4 style="color: black;text-align: center;"><?php echo $msg; ?></h4>
            <form action="#" method="POST">
      <fieldset>
       <legend><b> CREATE STUDENT:</b></legend>
  
        <label>STUDENT ID:</label>
        <br>
        <input type="text" name="student_id" placeholder="ENTER STUDENT ID" required="">
          <br> <br>
          <label>STUDENT NAME:</label><br>
          <input type="text" name="student_name" placeholder="ENTER STUDENT NAME" required="">
          <br>  <br>
         <label>EMAIL:</label><br>
          <input type="EMAIL" name ="email" placeholder="EMAIL" required="">
          <br>  <br>
            <label>CONTACT NO:</label><br>
          <input type="tel" name="mobile" placeholder="ENTER CONTACT NUMBER" required="">
          <br>  <br>




          <label>CLASS:</label> <br>

             <select name="class">
    <option value="F.Y">F.Y</option>
    <option value="S.Y">S.Y</option>
    <option value="T.Y">T.Y</option>
    
  </select>

  <br> <br>
  <label>SECTION:</label><br>
  <select name="section">
    <option value="BCOM">BCOM</option>
    <option value="BSC(I.T)">BSC(I.T)</option>
    <option value="BMS">BMS</option>
    <option value="BAF">BAF</option>
    <option value="BMM">BMM</option>
  </select>

          <br>    <br>
         <button style="padding: 10px;border-radius: 20px;">SAVE</button> 
        <!-- <button style="padding: 10px;border-radius: 20px;margin-left: 50px;">DELETE</button>  -->
        <button style="padding:10px; border-radius: 20px; margin-left: 50px;" onclick="location.href='index.php'">EXIT</button>
        </fieldset>
</form>
        </div>
       
    </body>
</html>