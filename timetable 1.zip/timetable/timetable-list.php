<?php

require('config.php');
$Timetable = array();
if(isset($_POST['section']))
{
    $class = $_POST['class'];
    $section = $_POST['section'];

    if(empty($class))
    {
        $msg = "Please Select Class";
    }
    elseif(empty($section))
    {
        $msg = "Please Select Section";
    }
    else
    {
        $sql = "SELECT sm.*,s.subject_name,s.display_color FROM `tbl_timetable` sm JOIN `tbl_subject` s ON sm.subject=s.id WHERE `section`='".$section."' AND `class`='".$class."' ORDER BY `day`,`period`";
        $stmt = $conn->query($sql);
        $Timetable = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// print_r($subject_list);
?>
<!doctype html>
<html>
<head>
  <title>Timetable List</title>
  <link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>
  <?php require('header.php'); ?>
       <div class="centerdiv_subject">
          <form action="#" method="POST">
            <fieldset>
              <legend><b> Create Timetable:</b></legend>
              <label>SECTION:</label><br>
                <select name="section" required>
                  <option <?= (isset($_POST['section']) && $_POST['section']=='BCOM')?'selected':''; ?> value="BCOM">BCOM</option>
                  <option <?= (isset($_POST['section']) && $_POST['section']=='BSC(I.T)')?'selected':''; ?> value="BSC(I.T)">BSC(I.T)</option>
                  <option <?= (isset($_POST['section']) && $_POST['section']=='BMS')?'selected':''; ?> value="BMS">BMS</option>
                  <option <?= (isset($_POST['section']) && $_POST['section']=='BAF')?'selected':''; ?> value="BAF">BAF</option>
                  <option <?= (isset($_POST['section']) && $_POST['section']=='BMM')?'selected':''; ?> value="BMM">BMM</option>
                </select>

            <br>    <br>
             <label>CLASS:</label> <br>

             <select name="class" required>
              <option <?= (isset($_POST['class']) && $_POST['class']=='F.Y')?'selected':''; ?> value="F.Y">F.Y</option>
              <option <?= (isset($_POST['class']) && $_POST['class']=='S.Y')?'selected':''; ?> value="S.Y">S.Y</option>
              <option <?= (isset($_POST['class']) && $_POST['class']=='T.Y')?'selected':''; ?> value="T.Y">T.Y</option>

            </select>

            <br> <br>

            <button style="padding: 10px;border-radius: 20px;">SAVE</button> 
            <!-- <button style="padding: 10px;border-radius: 20px;margin-left: 50px;">DELETE</button>  -->
            <button type="button" style="padding:10px; border-radius: 20px; margin-left: 10px;" onclick="location.href='index.php'">EXIT</button>
          </fieldset>
        </form>
        <?php if(count($Timetable)){ ?>
          <table id="myTable">
            <thead>
            <tr>
              <th>Periods</th>
              <th>Mon</th>
              <th>Tue</th>
              <th>Wed</th>
              <th>Thurs</th>
              <th>Fri</th>
              <th>Sat</th>
            </tr>
            </thead>
            <tbody>
              <tr>
            <?php
            $period=1;
              foreach ($Timetable as $key => $value) { if($key%6==0 && $key!=0){ echo '</tr>'; } if($key%6==0 && $key!=30){ echo '<td>'.$period.'</td>'; $period++; } ?>
                <!-- <tr> -->
                  <td style="background-color: <?php echo $value['display_color'] ?>; color: white"><?php echo $value['subject_name']; ?></td>
                <!-- </tr> -->
              <?php } ?>
              </tr>
            </tbody>
          </table>
        <?php } ?>
    </div>

  </body>
  </html>