<?php

require('config.php');

$sql = "SELECT * FROM `tbl_admin` WHERE `isDeleted`=0";
$stmt = $conn->query($sql);
$staff_list = $stmt->fetchAll(PDO::FETCH_ASSOC);

// print_r($subject_list);
?>
<!doctype html>
<html>
<head>
  <title>Subject List</title>
  <link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>
  <?php require('header.php'); ?>
       <div class="centerdiv_student">
        <table id="myTable">
          <thead>
                    <tr>
                       <th>Sr no </th>
            <th>Staff ID</th>
            <th>Staff Name</th>
            <th>Staff Email</th>
            <th>Staff Contactno</th>

           </tr>
          </thead>
          <tbody>
          <?php
            foreach ($staff_list as $key => $value) { ?>
              <tr>
                <th><?php echo $key+1; ?></th>
                <th><?php echo $value['id'] ?></th>
                <th><?php echo $value['name'] ?></th>

                <th><?php echo $value['email'] ?></th>
                <th><?php echo $value['CONTACT NUMBER'] ?></th>

              </tr>
            <?php }
          ?>
          </tbody>

        </table>

        <button style="padding:10px; border-radius: 20px; margin-left: 50px;" onclick="location.href='index.php'">EXIT</button>
    </div>

  </body>
  </html>