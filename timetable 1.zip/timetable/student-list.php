<?php

require('config.php');

$sql = "SELECT * FROM `tbl_student` WHERE `isDeleted`=0";
$stmt = $conn->query($sql);
$student_list = $stmt->fetchAll(PDO::FETCH_ASSOC);

// print_r($subject_list);
?>
<!doctype html>
<html>
<head>
  <title>Subject List</title>
  <link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>
  <?php require('header.php'); ?>
       <div class="centerdiv_student">
        <table id="myTable" >
          <thead>
          <tr>
            <th>Sr no</th>
            <th>Student ID</th>
            <th>Student Name</th>
            <th> Email</th>
            <th> Contactno</th>

            <th>Class</th>
            <th>Section</th>
          </tr>
          </thead>
          <tbody>          <?php
            foreach ($student_list as $key => $value) { ?>
              <tr>
                <th><?php echo $key+1; ?></th>
                <th><?php echo $value['student_id'] ?></th>
                <th><?php echo $value['student_name'] ?></th>

                <th><?php echo $value['email'] ?></th>
                <th><?php echo $value['contactno'] ?></th>

                <th><?php echo $value['class'] ?></th>
                <th><?php echo $value['section'] ?></th>
              </tr>
            <?php }
          ?>
          </tbody>

        </table>

        <button style="padding:10px; border-radius: 20px; margin-left: 50px;" onclick="location.href='index.php'">EXIT</button>
    </div>

  </body>
  </html>