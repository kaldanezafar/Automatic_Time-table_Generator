<?php
require('config.php');
if(!isset($_SESSION['admin_id']))
{
  header('location: login.php');
}

if(isset($_GET['logout']))
{
  // echo 'hi';
  // remove all session variables
  session_unset(); 

  // destroy the session 
  session_destroy(); 
  // print_r($_SESSION);
  header('location: login.php');
}

?>
<!doctype html>
<html>
<head>
    <title>loginpage</title>
    <link rel="stylesheet" type="text/css" href="css/index.css">
    </head>
    <body>
  <?php require('header.php'); ?>
    </body>
</html>