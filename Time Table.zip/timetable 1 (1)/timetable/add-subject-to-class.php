<?php

require('config.php');

$msg = "";
// print_r($_SESSION);

if(isset($_POST['section']))
{
    $subject = $_POST['subject'];
    $class = $_POST['class'];
    $section = $_POST['section'];


    if(empty($subject))
    {
        $msg = "Please Enter Student ID";
    }
    elseif(empty($class))
    {
        $msg = "Please Enter Password";
    }
    else
    {
        $sql = "INSERT INTO `tbl_subject_mapping`(`id`, `section`, `class`, `subject`) VALUES (NUll,'".$section."','".$class."','".$subject."')";
        $stmt = $conn->query($sql);
        if($stmt->rowCount()>0)
        {
            $msg = '<span style="color:green;">Mapped Created Successfully</span>';
           
        }
        else
        {
            $msg = 'ERROR';
        }
    }
}

$sql = "SELECT * FROM `tbl_subject` WHERE `isDeleted`=0";
$stmt = $conn->query($sql);
$subject_list = $stmt->fetchAll(PDO::FETCH_ASSOC);

// print_r($subject_list);
?>
<!doctype html>
<html>
<head>
  <title>Add subject to class</title>
  <link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>
  <?php require('header.php'); ?>
       <div class="centerdiv">
        <h4 style="color: black;text-align: center;"><?php echo $msg; ?></h4>
        <form action="#" method="POST">
          <fieldset>
            <legend><b> add subject to class:</b></legend>
            <label>SECTION:</label><br>
              <select name="section" required>
                <option value="BCOM">BCOM</option>
                <option value="BSC(I.T)">BSC(I.T)</option>
                <option value="BMS">BMS</option>
                <option value="BAF">BAF</option>
                <option value="BMM">BMM</option>
              </select>

          <br>    <br>
           <label>CLASS:</label> <br>

           <select name="class" required>
            <option value="F.Y">F.Y</option>
            <option value="S.Y">S.Y</option>
            <option value="T.Y">T.Y</option>

          </select>

          <br> <br>

          <label>SUBJECT:</label> <br>

           <select name="subject" required>
            <option value="">Select Subject</option>
            <?php
              foreach ($subject_list as $key => $value) { ?>
                <option value="<?php echo $value['id'] ?>"><?php echo $value['subject_name'] ?></option>
              <?php }
            ?>
          </select>

          <br> <br>
          
          <button style="padding: 10px;border-radius: 20px;">SAVE</button> 
          <!-- <button style="padding: 10px;border-radius: 20px;margin-left: 50px;">DELETE</button>  -->
          <button style="padding:10px; border-radius: 20px; margin-left: 50px;" onclick="location.href='index.php'">EXIT</button>
        </fieldset>
      </form>
    </div>

  </body>
  </html>