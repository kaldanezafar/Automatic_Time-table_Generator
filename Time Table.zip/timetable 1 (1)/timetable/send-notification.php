<!doctype html>
<html>
<head>
  <title>send notification</title>
  <link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>
   <?php require('header.php'); ?>
<div class="centerdiv">
   <form action="#" method="POST">
 
      <fieldset>
       <legend>MESSAGE:</legend>
   <label>WRITE YOUR MESSAGE HERE</label><br><input type="text" name="message" required>
   <br> <br>
  <button style="padding: 10px;border-radius: 20px;">Send Notification</button> 
  <!-- <button style="padding: 10px;border-radius: 20px;margin-left: 50px;">DELETE</button>  -->
 
 <button style="padding:10px; border-radius: 20px; margin-left: 50px;" onclick="location.href='index.php'">EXIT</button>
        
         </fieldset>
</form>
</div>
</body>
</html>