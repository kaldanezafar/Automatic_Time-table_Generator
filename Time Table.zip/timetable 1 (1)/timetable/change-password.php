<!doctype html>
<html>
<head>
	<title>CHANGE PASSWORD</title>
	    <link rel="stylesheet" type="text/css" href="css/login.css.css">

</head>
<body>

	<label>OLD PASSWORD</label>
	<br>
	<input type="text" name="" >
	<br><br>

	<label>NEW PASSWORD</label>
	<br>
	<input type="text" name="" >
	<br><br>

</body>
</html>