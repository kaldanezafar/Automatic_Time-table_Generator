<?php

require('config.php');

$msg = "";
// print_r($_SESSION);

if(!isset($_SESSION['admin_id']))
{
  header('location: login.php');
}

if(isset($_POST['staff_id']))
{
    $staff_id = $_POST['staff_id'];
    $staff_name = $_POST['staff_name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];

    if(empty($staff_id))
    {
        $msg = "Please Enter Admin ID";
    }
    elseif(empty($staff_name))
    {
        $msg = "Please Enter Password";
    }
    else
    {
      $sql = "INSERT INTO `tbl_admin`(`id`, `name`, `email`, `CONTACT NUMBER`, `password`, `status`, `added_date`, `updated_date`, `isDeleted`) VALUES (NULL,'".$staff_name."','".$email."','".$mobile."','1234',0,NOW(),NOW(),0)";
      $stmt = $conn->query($sql);
      if($stmt->rowCount()>0)
      {
          $msg = '<span style="color:green;">Staff Created Successfully</span>';
      }
      else
      {
          $msg = 'Please Enter Valid Credential';
      }
    }
}

?>
<!doctype html>
<html>
<head>
    <title>create student</title>
    <link rel="stylesheet" type="text/css" href="css/index.css">
    </head>
    <body>
      <?php require('header.php'); ?>
 <div class="centerdiv">
  <h4 style="color: black;text-align: center;"><?php echo $msg; ?></h4>
  <form action="#" method="POST">
      <fieldset>
       <legend><b> CREATE STAFF:</b></legend>
  
        
            <label>STAFF ID:</label><br>

            <input type="text" name="staff_id" placeholder="ENTER STAFF ID" required="">
        <br>    <br>
        <label>STAFF NAME:</label><br>
        <input type="text" name="staff_name" placeholder="ENTER STAFF NAME" required="">
          <br>  <br>
         <label>EMAIL:</label><br>
          <input type="EMAIL" name="email" placeholder="EMAIL" required="">
          <br>  <br>
            <label>CONTACT NO:</label><br>
          <input type="tel" name="mobile" placeholder="CONTACT NUMBER" required="">
          <br>  <br>
   <button style="padding: 10px;border-radius: 20px;">SAVE</button> 
       <!--  <button style="padding: 10px;border-radius: 20px;margin-left: 50px;">DELETE</button> --> 
        <button style="padding:10px; border-radius: 20px; margin-left: 50px;" onclick="location.href='index.php'">EXIT</button>
        
         </fieldset>
</form>
        </div>
       
    </body>
</html>