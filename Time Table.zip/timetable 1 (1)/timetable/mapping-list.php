<?php

require('config.php');

$sql = "SELECT sm.*,s.subject_name FROM `tbl_subject_mapping` sm JOIN `tbl_subject` s ON sm.subject=s.id";
$stmt = $conn->query($sql);
$subject_list = $stmt->fetchAll(PDO::FETCH_ASSOC);

// print_r($subject_list);
?>
<!doctype html>
<html>
<head>
  <title>Subject List</title>
  <link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>
  <?php require('header.php'); ?>
       <div class="centerdiv_subject">
        <table id="myTable">
          <thead>
          <tr>
                      <th>sr no</th>
                      <th>ID</th>
                       <th>Section</th>
            <th>class</th>
            <th>Subject </th>
          </tr>
          </thead>
          <tbody>
          <?php
            foreach ($subject_list as $key => $value) { ?>
              <tr>
                <th><?php echo $key+1; ?></th>
                <th><?php echo $value['id'] ?></th>
                <th><?php echo $value['section'] ?></th>
                 <th><?php echo $value['class'] ?></th>
                <th><?php echo $value['subject_name'] ?></th>
              </tr>
            <?php }
          ?>
          </tbody>
        </table>

        <button style="padding:10px; border-radius: 20px; margin-left: 50px;" onclick="location.href='index.php'">EXIT</button>
    </div>

  </body>
  </html>