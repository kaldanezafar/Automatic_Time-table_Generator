<?php

require('config.php');

$sql = "SELECT * FROM `tbl_subject` WHERE `isDeleted`=0";
$stmt = $conn->query($sql);
$subject_list = $stmt->fetchAll(PDO::FETCH_ASSOC);

// print_r($subject_list);
?>
<!doctype html>
<html>
<head>
  <title>Subject List</title>
  <link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>
  <?php require('header.php'); ?>
       <div class="centerdiv_subject">
        <table id="myTable">
          <thead>
          <tr>
            <th>Sr No</th>
            <th>Subject ID</th>
            <th>Subject Name</th>
            <th>Subject Color</th>
          </tr>
          </thead>
          <tbody>
          <?php
            foreach ($subject_list as $key => $value) { ?>
              <tr>
                <th><?php echo $key+1; ?></th>
                <th><?php echo $value['subject_id'] ?></th>
                <th><?php echo $value['subject_name'] ?></th>
                <th><div style="height: 50px;width: 50px;background-color: <?php echo $value['display_color'] ?>"></div></th>
              </tr>
            <?php }
          ?>
          </tbody>
        </table>

        <button style="padding:10px; border-radius: 20px; margin-left: 50px;" onclick="location.href='index.php'">EXIT</button>
    </div>

  </body>
  </html>